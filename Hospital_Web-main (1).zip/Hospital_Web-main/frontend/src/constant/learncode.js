export const learncode = "LearnCode";
