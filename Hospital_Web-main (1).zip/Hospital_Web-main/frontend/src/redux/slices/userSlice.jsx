import { axiosInstance } from "@/constant/axios";
import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

export const userSlice = createSlice({
    name: "user",
    initialState: {
        loading: false,
        user: null,
        error: null,
        isAuthenticated: false,
        // selectedLink: null
        appointment: null
    },
    reducers: {
        setLoading: (state, action) => {
            state.loading = action.payload;
        },
        setUser: (state, action) => {
            state.user = action.payload;
            state.isAuthenticated = true;
            state.error = null;
        },
        setAppointment: (state, action) => {
            state.appointment = action.payload;
            state.error = null;
        },
        setError: (state, action) => {
            state.error = action.payload;
        },
        // setSelectedLink: (state, action) => {
        //     state.selectedLink = action.payload;
        // },
        setLogout: (state) => {
            state.user = null;
            state.isAuthenticated = false;
            state.error = null;
        },
    },
});

export const { setLoading, setUser, setAppointment, setError, setLogout, setSelectedLink } = userSlice.actions;
export default userSlice.reducer;

// Register
export const registerUser = (userData) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const { data } = await axiosInstance.post("/user/register", userData);
        if (data?.success) {
            dispatch(setUser(data.user));
            toast.success(data.message);
            window.location.href = "/"
            // setTimeout(() => navigate("/dashboard"), 1200);
        }
    } catch (err) {
        dispatch(setError(err.response?.data?.message || "Registration failed"));
        toast.error(err.response?.data?.message || "Registration failed");
    } finally {
        dispatch(setLoading(false));
    }
};

// Login
export const loginUser = (userData) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const { data } = await axiosInstance.post("/user/login", userData);
        if (data?.success) {
            dispatch(setUser(data.user));
            toast.success(data.message);
            // navigate("/")
            window.location.href = "/"
            // setTimeout(() => navigate("/"), 1200);
        }

    } catch (err) {
        dispatch(setError(err.response?.data?.message || "Login failed"));
        toast.error(err.response?.data?.message || "Login failed");
    } finally {
        dispatch(setLoading(false));
    }
};

// Logout
export const logoutUser = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const { data } = await axiosInstance.get("/user/logout");
        if (data?.success) {
            dispatch(setLogout());
            toast.success(data.message);
            window.location.href = "/"
            // setTimeout(() => window.location.href = "/", 1200);
        }
    } catch (err) {
        dispatch(setError(err.response?.data?.message || "Logout failed"));
        toast.error(err.response?.data?.message || "Logout failed");
    } finally {
        dispatch(setLoading(false));
    }
};

// Get Profile
export const getUserProfile = () => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const { data } = await axiosInstance.get("/user/profile");
        console.log("data :", data);

        if (data?.success) {
            dispatch(setUser(data?.profile || data?.user)); // Ensure consistency
        }
    } catch (err) {
        dispatch(setError(err.response?.data?.message || "Fetching profile failed"));
        // toast.error(err.response?.data?.message || "Fetching profile failed");
    } finally {
        dispatch(setLoading(false));
    }
};
// // Get Profile
// export const updateUserProfile = (profileData) => async (dispatch) => {
//     dispatch(setLoading(true));
//     console.log("profileData :", profileData);

//     try {
//         const { data } = await axiosInstance.put('/user/update/profile', profileData)
//         console.log("data update:", data);

//         if (data?.success) {
//             // dispatch(getUserProfile());
//             dispatch(setUser(data?.user)); // Ensure consistency
//             toast.success(data?.message)
//         }
//     } catch (err) {
//         dispatch(setError(err.response?.data?.message || "Fetching profile failed"));
//         // toast.error(err.response?.data?.message || "Fetching profile failed");
//     } finally {
//         dispatch(setLoading(false));
//     }
// };
export const forgotPassword = (email) => async (dispatch) => {
    dispatch(setLoading(true));
    try {
        const { data } = await axiosInstance.post(`/user/forgot-password`, {
            email,
        });
        if (data?.success)
            toast.success(data.message || "Password reset link sent");
    } catch (err) {
        dispatch(setError(err?.response?.data?.message || "Request failed"));
        toast.error(err?.response?.data?.message || "Request failed");
    } finally {
        dispatch(setLoading(false));
    }
};


