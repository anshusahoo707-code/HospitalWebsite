/* eslint-disable react/prop-types */
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";



const Modal = ({ selectedPatient, setSelectedPatient, title = false, name, children, close }) => {
    return (
        <Dialog open={!!selectedPatient} onOpenChange={() => setSelectedPatient(null)}>
            <DialogContent className="max-w-4xl bg-white">
                {title ? <DialogHeader>
                    <DialogTitle>{title || 'Patient Details'}</DialogTitle>
                    <DialogDescription>
                        {`Full details of the selected ${name || 'patient'}, including records and appointments.`}
                    </DialogDescription>
                </DialogHeader> : ""}

                {children}

                {close && <DialogFooter>
                    <Button variant="outline" onClick={() => setSelectedPatient(null)}>
                        Close
                    </Button>
                </DialogFooter>}
            </DialogContent>
        </Dialog>

    )
}

export default Modal